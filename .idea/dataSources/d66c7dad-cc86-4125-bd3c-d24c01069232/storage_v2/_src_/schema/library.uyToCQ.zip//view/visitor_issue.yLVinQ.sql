create definer = root@localhost view visitor_issue as
select `library`.`book_issues`.`issue_id`                                                      AS `issue_id`,
       `library`.`book_issues`.`issue_clear`                                                   AS `issue_clear`,
       `library`.`visitors`.`visitor_uid`                                                      AS `visitor_uid`,
       concat(`library`.`visitors`.`visitor_fname`, ' ', `library`.`visitors`.`visitor_lname`) AS `visitor_name`,
       `library`.`books`.`book_id`                                                             AS `book_id`,
       `library`.`books`.`book_name`                                                           AS `book_name`,
       `library`.`books`.`book_author`                                                         AS `book_author`
from `library`.`visitors`
         join `library`.`book_issues`
         join `library`.`books`
where ((`library`.`book_issues`.`visitor_uid` = `library`.`visitors`.`visitor_uid`) and
       (`library`.`book_issues`.`book_id` = `library`.`books`.`book_id`));

